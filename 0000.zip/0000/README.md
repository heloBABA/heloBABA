# DIAJZS - Instagram Content Downloader

A modern, responsive web application that allows users to download Instagram content including photos, videos, reels, and stories.

## Features

- Photo downloading
- Video downloading
- Reels downloading
- Story downloading
- Responsive design
- Modern UI with gradients and animations
- AdSense integration
- Contact form
- Privacy policy and terms of service

## Project Structure

```
project-folder/
│
├── index.html               → Main homepage file
├── about.html              → About page
├── services.html           → Services page
├── contact.html            → Contact page with form
├── privacy.html            → Privacy policy
├── terms.html             → Terms of service
│
├── style/                  → All CSS files
│   ├── main.css            → Main stylesheet
│   ├── chat.css            → Chat feature styles
│   └── tool.css            → Tool-specific styles
│
├── js/                     → All JavaScript files
│   └── main.js             → Main JavaScript logic
│
├── assets/                 → All media and resources
│   ├── images/             → All website images
│   ├── icons/              → All UI and social media icons
│   └── fonts/             → Web fonts
│
└── README.md               → Project information
```

## Setup

1. Clone the repository
2. Install the required dependencies from requirements.txt
3. Run the server using Python: `python server.py`
4. Access the website at http://localhost:8000 

# DIAJZS - C-Panel Hosting Instructions

## How to Host on C-Panel (Shared Hosting)

1. **Download your website files**
   - All files and folders in this project (except backend/server files) are ready for static hosting.
   - You only need: `index.html`, `contact.html`, `terms.html`, the `tools/`, `js/`, `style/`, and `assets/` folders.

2. **Remove backend/server files**
   - Do NOT upload any backend files like `server.py`, `requirements.txt`, or any Node.js/Express code. This site is now 100% static and C-Panel compatible.

3. **Upload to C-Panel**
   - Log in to your C-Panel.
   - Go to the File Manager.
   - Upload all files and folders to the `public_html` directory (or your main web root).
   - Make sure `index.html` is in the root of `public_html`.
   - All folders (`tools`, `js`, `style`, `assets`) should be in the same structure as here.

4. **Check your links**
   - All navigation and tool links are relative and will work on any host.
   - If you use subdomains or subfolders, adjust links as needed.

5. **(Optional) .htaccess**
   - If you want to force HTTPS or add pretty URLs, you can add a `.htaccess` file. Example:

```
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

6. **Go Live!**
   - Visit your domain in the browser. Your site should work exactly as designed.

---

**No backend or server-side code is required. All tools are static HTML/CSS/JS and will work perfectly on C-Panel shared hosting.**

If you add new tools, just place their HTML in the `tools/` folder and link them from `index.html`. 