// Main JavaScript functionality for DIAJZS
document.addEventListener('DOMContentLoaded', function() {
    // Initialize download functionality
    initializeDownloader();
    
    // Initialize responsive navigation
    initializeNavigation();
    
    // Initialize contact form
    initializeContactForm();

    // Set language from localStorage or default to EN
    setLanguage(localStorage.getItem('lang') || 'EN');

    // Toggle language dropdown
    const langSwitch = document.querySelector('.lang-switch');
    if (langSwitch) {
        langSwitch.style.position = 'relative';
        langSwitch.addEventListener('click', function(e) {
            e.stopPropagation();
            createLangDropdown();
        });
        document.body.addEventListener('click', function() {
            const dropdown = document.querySelector('.lang-dropdown');
            if (dropdown) dropdown.style.display = 'none';
        });
    }
});

function initializeDownloader() {
    const downloadForm = document.getElementById('download-form');
    if (downloadForm) {
        downloadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const url = document.getElementById('instagram-url').value;
            try {
                const response = await fetch('/download', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ url: url })
                });
                const data = await response.json();
                // Handle the download response
                if (data.success) {
                    window.location.href = data.downloadUrl;
                } else {
                    alert('Download failed. Please try again.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            }
        });
    }
}

function initializeNavigation() {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav');
    
    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            nav.classList.toggle('active');
        });
    }
}

function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(contactForm);
            try {
                const response = await fetch('/contact', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                if (data.success) {
                    alert('Message sent successfully!');
                    contactForm.reset();
                } else {
                    alert('Failed to send message. Please try again.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            }
        });
    }
}

// Multi-language support
const translations = {
  EN: {
    home: 'Home',
    tools: 'Tools',
    contact: 'Contact',
    signin: 'Sign In',
    try: 'Try For Free',
    heroTitle: 'Start your dream site with AI. Zero code, maximum speed.',
    heroInput: 'Ask anything or search...',
    heroBtn: '+ Start with AI',
    announce: 'Announcing DIAJZS AI →',
  },
  ES: {
    home: 'Inicio',
    tools: 'Herramientas',
    contact: 'Contacto',
    signin: 'Iniciar sesión',
    try: 'Pruébalo gratis',
    heroTitle: 'Crea tu sitio soñado con IA. Sin código, máxima velocidad.',
    heroInput: 'Pregunta o busca...',
    heroBtn: '+ Empezar con IA',
    announce: 'Anunciando DIAJZS AI →',
  },
  FR: {
    home: 'Accueil',
    tools: 'Outils',
    contact: 'Contact',
    signin: 'Se connecter',
    try: 'Essayez gratuitement',
    heroTitle: 'Créez votre site de rêve avec l\'IA. Zéro code, vitesse maximale.',
    heroInput: 'Demandez ou recherchez...',
    heroBtn: '+ Commencer avec l\'IA',
    announce: 'Annonce DIAJZS AI →',
  },
  DE: {
    home: 'Startseite',
    tools: 'Werkzeuge',
    contact: 'Kontakt',
    signin: 'Anmelden',
    try: 'Kostenlos testen',
    heroTitle: 'Starte deine Traumseite mit KI. Kein Code, maximale Geschwindigkeit.',
    heroInput: 'Frage etwas oder suche...',
    heroBtn: '+ Mit KI starten',
    announce: 'DIAJZS KI angekündigt →',
  },
  IT: {
    home: 'Home',
    tools: 'Strumenti',
    contact: 'Contatto',
    signin: 'Accedi',
    try: 'Prova gratis',
    heroTitle: 'Crea il tuo sito da sogno con l\'IA. Zero codice, massima velocità.',
    heroInput: 'Chiedi o cerca...',
    heroBtn: '+ Inizia con l\'IA',
    announce: 'Annunciando DIAJZS AI →',
  }
};

function setLanguage(lang) {
  localStorage.setItem('lang', lang);
  const t = translations[lang] || translations['EN'];
  // Navigation
  document.querySelectorAll('.modern-menu li a')[0].textContent = t.home;
  document.querySelectorAll('.modern-menu li a')[1].textContent = t.tools;
  document.querySelectorAll('.modern-menu li a')[2].textContent = t.contact;
  document.querySelector('.lang-switch span').textContent = lang;
  // Buttons
  const signin = document.querySelector('.modern-signin-btn');
  if (signin) signin.textContent = t.signin;
  const tryBtn = document.querySelector('.modern-try-btn');
  if (tryBtn) tryBtn.textContent = t.try;
  // Hero section (if present)
  const heroTitle = document.querySelector('.ai-hero-title');
  if (heroTitle) heroTitle.textContent = t.heroTitle;
  const aiInput = document.getElementById('ai-search-input');
  if (aiInput) aiInput.placeholder = t.heroInput;
  const aiBtn = document.querySelector('.ai-search-btn');
  if (aiBtn) aiBtn.textContent = t.heroBtn;
  const announce = document.querySelector('.ai-announce');
  if (announce) announce.textContent = t.announce;
}

// Language dropdown
function createLangDropdown() {
  let dropdown = document.querySelector('.lang-dropdown');
  if (!dropdown) {
    dropdown = document.createElement('div');
    dropdown.className = 'lang-dropdown';
    dropdown.style.position = 'absolute';
    dropdown.style.top = '40px';
    dropdown.style.right = '0';
    dropdown.style.background = '#23232b';
    dropdown.style.borderRadius = '8px';
    dropdown.style.boxShadow = '0 2px 8px rgba(0,0,0,0.12)';
    dropdown.style.zIndex = '2000';
    dropdown.style.padding = '8px 0';
    ['EN','ES','FR','DE','IT'].forEach(l => {
      const opt = document.createElement('div');
      opt.textContent = l;
      opt.style.padding = '8px 32px 8px 18px';
      opt.style.cursor = 'pointer';
      opt.style.color = '#fff';
      opt.style.fontWeight = '600';
      opt.addEventListener('click', () => {
        setLanguage(l);
        dropdown.style.display = 'none';
      });
      dropdown.appendChild(opt);
    });
    document.querySelector('.lang-switch').appendChild(dropdown);
  }
  dropdown.style.display = 'block';
}

// Dynamic Time-of-Day Animated Background for DIAJZS
(function() {
  const canvas = document.getElementById('dynamic-bg');
  if (!canvas) return;
  let ctx = canvas.getContext('2d');
  let width = window.innerWidth;
  let height = window.innerHeight;
  let timeState = '';

  // Night-only rocket and shooting star/asteroid (single run)
  let rocketLaunched = false;
  let rocket = null;
  let rocketTrail = [];
  let shootingStarLaunched = false;
  let shootingStar = null;
  let shootingStarDelay = 0;

  // Galaxy animation (night-only, ultra-smooth, high-res, 10-minute duration, photo-inspired, refined)
  let galaxyActive = false;
  let galaxy = null;
  let nextGalaxyDelay = 0;

  // --- Animation frame rate control ---
  let lastFrameTime = 0;
  const FRAME_INTERVAL = 1000 / 30; // 30fps

  function resizeCanvas() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
  }

  function getTimeState() {
    const now = new Date();
    const h = now.getHours() + now.getMinutes()/60;
    if (h >= 5 && h < 11) return 'morning';
    if (h >= 11 && h < 16) return 'afternoon';
    if (h >= 16 && h < 19.5) return 'evening';
    return 'night';
  }

  // --- Drawing helpers ---
  function drawSun(x, y, r, color) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 40;
    ctx.fill();
    ctx.restore();
  }
  function drawMoon(x, y, r) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.fillStyle = '#fffbe6';
    ctx.shadowColor = '#fffbe6';
    ctx.shadowBlur = 30;
    ctx.fill();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x + r/2, y - r/3, r*0.9, 0, 2 * Math.PI);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }
  function drawCloud(x, y, scale, t) {
    ctx.save();
    ctx.globalAlpha = 0.7;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.ellipse(x + Math.sin(t/700)*10, y, 32*scale, 18*scale, 0, 0, 2*Math.PI);
    ctx.ellipse(x+20*scale, y+8*scale, 20*scale, 12*scale, 0, 0, 2*Math.PI);
    ctx.ellipse(x-20*scale, y+8*scale, 20*scale, 12*scale, 0, 0, 2*Math.PI);
    ctx.fill();
    ctx.restore();
  }
  function drawBird(x, y, scale, t) {
    ctx.save();
    ctx.strokeStyle = '#444';
    ctx.lineWidth = 2*scale;
    ctx.beginPath();
    ctx.arc(x, y, 8*scale, Math.PI, Math.PI*1.7, false);
    ctx.arc(x+16*scale, y, 8*scale, Math.PI*1.2, Math.PI*2, false);
    ctx.stroke();
    ctx.restore();
  }
  function drawStars(num, t) {
    num = Math.floor(num * 0.6); // Reduce number of stars for performance
    for (let i = 0; i < num; i++) {
      const x = (i*9973 % width);
      const y = (i*7919 % height*0.7);
      const r = 0.7 + (i*13 % 7)/4;
      const twinkle = 0.5 + 0.5*Math.sin(t/800 + i);
      ctx.save();
      ctx.globalAlpha = twinkle;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, 2*Math.PI);
      ctx.fillStyle = '#fffbe6';
      ctx.shadowColor = '#fffbe6';
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.restore();
    }
  }

  function launchRocket() {
    rocketLaunched = true;
    rocket = {
      x: 60,
      y: height - 60,
      vx: (width - 120) / 120,
      vy: -(height - 120) / 120,
      t: 0,
      duration: 120,
      finished: false
    };
    rocketTrail = [];
  }

  function launchShootingStar() {
    shootingStarLaunched = true;
    shootingStar = {
      x: 40,
      y: 40,
      vx: (width - 80) / 80,
      vy: (height - 80) / 80,
      t: 0,
      duration: 80,
      finished: false
    };
  }

  function launchGalaxy() {
    galaxyActive = true;
    galaxy = {
      x: 220,
      y: height - 220,
      startX: 220,
      startY: height - 220,
      endX: width * 0.85,
      endY: height * 0.13,
      t: 0,
      duration: 36000, // 10 minutes at 60fps (600,000ms / 16.67ms)
      finished: false
    };
  }

  function drawRocket(r) {
    // Trail with red accent
    rocketTrail.push({x: r.x, y: r.y, alpha: 1});
    if (rocketTrail.length > 30) rocketTrail.shift();
    for (let i = 0; i < rocketTrail.length; i++) {
      ctx.save();
      ctx.globalAlpha = rocketTrail[i].alpha * (i / rocketTrail.length);
      ctx.beginPath();
      ctx.arc(rocketTrail[i].x, rocketTrail[i].y, 8, 0, 2 * Math.PI);
      // Red accent in the trail
      ctx.fillStyle = i > rocketTrail.length * 0.7 ? 'rgba(255,80,80,0.5)' : 'rgba(255,255,200,0.5)';
      ctx.shadowColor = i > rocketTrail.length * 0.7 ? 'rgba(255,80,80,0.7)' : '#fffbe6';
      ctx.shadowBlur = 16;
      ctx.fill();
      ctx.restore();
    }
    // Rocket body
    ctx.save();
    ctx.translate(r.x, r.y);
    ctx.rotate(Math.atan2(r.vy, r.vx) - Math.PI/2);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(8, 24);
    ctx.lineTo(-8, 24);
    ctx.closePath();
    ctx.fillStyle = '#fff';
    ctx.shadowColor = '#fffbe6';
    ctx.shadowBlur = 10;
    ctx.fill();
    // Window
    ctx.beginPath();
    ctx.arc(0, 10, 3, 0, 2 * Math.PI);
    ctx.fillStyle = '#b3e0ff';
    ctx.fill();
    ctx.restore();
  }

  function drawShootingStar(s) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(s.x, s.y, 5, 0, 2 * Math.PI);
    ctx.fillStyle = '#fffbe6';
    ctx.shadowColor = '#fffbe6';
    ctx.shadowBlur = 20;
    ctx.globalAlpha = 0.8;
    ctx.fill();
    // Trail with red accent
    for (let i = 0; i < 10; i++) {
      ctx.beginPath();
      ctx.arc(s.x - s.vx*i*0.7, s.y - s.vy*i*0.7, 4-i*0.3, 0, 2*Math.PI);
      ctx.globalAlpha = i > 6 ? 0.18 : 0.15;
      ctx.fillStyle = i > 6 ? 'rgba(255,80,80,0.4)' : 'rgba(255,255,200,0.15)';
      ctx.shadowColor = i > 6 ? 'rgba(255,80,80,0.7)' : '#fffbe6';
      ctx.shadowBlur = 10;
      ctx.fill();
    }
    ctx.restore();
  }

  // --- Enhanced Galaxy (bigger, animated rings) ---
  function drawGalaxy(g, t) {
    // Calculate position with ease-in-out for cinematic effect
    const progress = g.t / g.duration;
    const eased = 0.5 - 0.5 * Math.cos(Math.PI * progress); // easeInOutSine
    const x = g.startX + (g.endX - g.startX) * eased;
    const y = g.startY + (g.endY - g.startY) * eased;
    const fade = progress < 0.95 ? 1 : 1 - (progress - 0.95) / 0.05;

    ctx.save();
    ctx.globalAlpha = 0.7 * fade;

    // Main glowing blue planet (core, bigger)
    let grad = ctx.createRadialGradient(x, y, 0, x, y, 180);
    grad.addColorStop(0, 'rgba(120,200,255,0.85)');
    grad.addColorStop(0.18, 'rgba(80,180,255,0.6)');
    grad.addColorStop(0.35, 'rgba(80,180,255,0.4)');
    grad.addColorStop(0.7, 'rgba(40,80,200,0.13)');
    grad.addColorStop(1, 'rgba(40,20,80,0)');
    ctx.beginPath();
    ctx.arc(x, y, 180, 0, 2 * Math.PI);
    ctx.fillStyle = grad;
    ctx.shadowColor = 'rgba(120,200,255,0.4)';
    ctx.shadowBlur = 40;
    ctx.fill();

    // Four animated rings (vibrating, rotating)
    for (let ring = 0; ring < 4; ring++) {
      ctx.save();
      ctx.globalAlpha = 0.18 * fade;
      ctx.translate(x, y);
      const baseAngle = -Math.PI / 6 + ring * Math.PI / 8 + Math.sin(t / 2000 + ring) * 0.08;
      ctx.rotate(baseAngle + Math.sin(t / (3000 + ring * 500)) * 0.09);
      let ringGrad = ctx.createLinearGradient(-180 - ring * 18, 0, 180 + ring * 18, 0);
      ringGrad.addColorStop(0, 'rgba(120,200,255,0)');
      ringGrad.addColorStop(0.18, 'rgba(120,200,255,0.13)');
      ringGrad.addColorStop(0.5, 'rgba(255,255,255,0.18)');
      ringGrad.addColorStop(0.82, 'rgba(120,200,255,0.13)');
      ringGrad.addColorStop(1, 'rgba(120,200,255,0)');
      ctx.beginPath();
      ctx.ellipse(0, 0, 180 + ring * 18, 48 + ring * 8, 0, 0, 2 * Math.PI);
      ctx.fillStyle = ringGrad;
      ctx.shadowColor = 'rgba(120,200,255,0.12)';
      ctx.shadowBlur = 18;
      ctx.fill();
      ctx.restore();
    }

    // Subtle star glows and clusters around the planet (more, higher quality)
    for (let i = 0; i < 18; i++) {
      const angle = Math.random() * 2 * Math.PI;
      const radius = 210 + Math.random() * 80;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius * 0.7;
      ctx.save();
      ctx.globalAlpha = 0.11 * fade;
      ctx.beginPath();
      ctx.arc(px, py, 2.5 + Math.random()*2, 0, 2 * Math.PI);
      ctx.fillStyle = '#fffbe6';
      ctx.shadowColor = '#fffbe6';
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.restore();
    }

    // (Optional) Second planet/nebula for extra realism (smaller, more luminous)
    let x2 = x + 180;
    let y2 = y + 40;
    let grad2 = ctx.createRadialGradient(x2, y2, 0, x2, y2, 60);
    grad2.addColorStop(0, 'rgba(120,200,255,0.5)');
    grad2.addColorStop(0.3, 'rgba(80,180,255,0.13)');
    grad2.addColorStop(1, 'rgba(40,80,200,0)');
    ctx.beginPath();
    ctx.arc(x2, y2, 60, 0, 2 * Math.PI);
    ctx.fillStyle = grad2;
    ctx.shadowColor = 'rgba(120,200,255,0.08)';
    ctx.shadowBlur = 12;
    ctx.globalAlpha = 0.22 * fade;
    ctx.fill();

    ctx.restore();
  }

  // --- Main animation loop ---
  function animate(t) {
    if (t - lastFrameTime < FRAME_INTERVAL) {
      requestAnimationFrame(animate);
      return;
    }
    lastFrameTime = t;
    ctx.clearRect(0, 0, width, height);
    timeState = getTimeState();
    // Sky gradient
    let grad;
    if (timeState === 'morning') {
      grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#b3e0ff');
      grad.addColorStop(1, '#fffbe6');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      // Sun rising
      const sunY = height*0.8 - Math.sin((t/4000)%Math.PI)*height*0.4;
      drawSun(width*0.5, sunY, 60, '#ffe066');
      // Birds
      for (let i=0; i<3; i++) drawBird(width*0.2+i*width*0.2 + Math.sin(t/1000+i)*30, height*0.25+Math.sin(t/1200+i)*10, 1+0.2*Math.sin(t/900+i), t);
    } else if (timeState === 'afternoon') {
      grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#6ec6ff');
      grad.addColorStop(1, '#fffbe6');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      // Sun high
      drawSun(width*0.8, height*0.2 + Math.sin(t/3000)*10, 70, '#ffe066');
      // Clouds
      for (let i=0; i<4; i++) drawCloud(width*(0.2+i*0.2)+Math.sin(t/1500+i)*40, height*0.18+Math.sin(t/1100+i)*10, 1+0.2*Math.sin(t/900+i), t);
    } else if (timeState === 'evening') {
      grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#ffb347');
      grad.addColorStop(0.5, '#ffcc80');
      grad.addColorStop(1, '#ff758c');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      // Sun setting
      const sunY = height*0.8 - Math.cos((t/4000)%Math.PI)*height*0.3;
      drawSun(width*0.5, sunY, 60, '#ffb347');
      // Clouds
      for (let i=0; i<2; i++) drawCloud(width*(0.3+i*0.3)+Math.sin(t/1200+i)*30, height*0.22+Math.sin(t/900+i)*8, 1+0.2*Math.sin(t/700+i), t);
    } else {
      // Night
      grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#18122b');
      grad.addColorStop(1, '#2d1850');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      // Moon
      drawMoon(width*0.8, height*0.18, 38);
      // Stars
      drawStars(60, t);
      // Rocket launch logic
      if (!rocketLaunched) {
        launchRocket();
      }
      if (rocket && !rocket.finished) {
        drawRocket(rocket);
        rocket.x += rocket.vx;
        rocket.y += rocket.vy;
        rocket.t++;
        if (rocket.t > rocket.duration) {
          rocket.finished = true;
          // Schedule shooting star after 5-10s
          shootingStarDelay = t + 5000 + Math.random()*5000;
        }
      }
      // Shooting star logic
      if (rocket && rocket.finished && !shootingStarLaunched && t > shootingStarDelay) {
        launchShootingStar();
      }
      if (shootingStar && !shootingStar.finished) {
        drawShootingStar(shootingStar);
        shootingStar.x += shootingStar.vx;
        shootingStar.y += shootingStar.vy;
        shootingStar.t++;
        if (shootingStar.t > shootingStar.duration) {
          shootingStar.finished = true;
        }
      }
      // Galaxy logic
      if (!galaxyActive && t > nextGalaxyDelay) {
        launchGalaxy();
      }
      if (galaxy && !galaxy.finished) {
        drawGalaxy(galaxy, t);
        galaxy.t++;
        if (galaxy.t > galaxy.duration) {
          galaxy.finished = true;
          galaxyActive = false;
          nextGalaxyDelay = t + 3000 + Math.random()*3000; // 3-6s delay before next galaxy
        }
      }
    }
    requestAnimationFrame(animate);
  }

  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();
  animate(0);
})(); 