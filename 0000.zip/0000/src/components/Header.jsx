.hero.ai-hero {
    background: radial-gradient(ellipse at 60% 40%, #2d1850 60%, #18122b 100%);
    /* ...other styles... */
} 

#dynamic-bg {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 0;
    pointer-events: none;
    display: block;
}
body > *:not(#dynamic-bg) {
    position: relative;
    z-index: 2;
} 